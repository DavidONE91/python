# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 18:50:44 2019

@author: CEC
"""

import fibonacci
fibonacci.fib(1000)