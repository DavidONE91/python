# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 18:48:11 2019

@author: CEC
"""
"""
def fibonacci(x):
    secuencia=[]
    numIni=0
    numFin=1
    
    for i in range (x):
        secuencia.append(numIni)
        numIni=numFin
"""  
      
def fib(n):
    a, b = 0, 1 #asignacion múltiple
    while a < n:
        print(a, end=' ')
        """
        c=a+b
        a=b
        b=c
        """
        a, b = b, a+b
    print()
fib(50)   