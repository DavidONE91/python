# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 18:28:57 2019

@author: CEC
"""
"""
print("Quiero ser un modulo")
"""

if __name__=="__main__":
    print("I prefer to be a module")
else:
    print("I like to be a module")    