# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 20:02:13 2019

@author: CEC
"""
##
"""
import math
x=float(input("Enter x: "))
y=math.sqrt(x)
print("The square root of",x,"equals to",y)
"""
"""
try:
    print("1")
    x=1/0
    print("2")
except:
    print("Oh dear, something went wrong...")
        
print("3")
"""
#
"""
try:
    x=int(input("Enter a number: "))
    y=1/x
    print(y)
except ZeroDivisionError:
    print("you cannot divide by zero, sorry.")
except ValueError:
    print("You must enter an integer value.")
except:
    print("Oh dear, something went wrong...")
print("THE END.")
"""
#
"""
try:
    y=1/0

except ArithmeticError:
    print("Arithmetic prblem")
    
except ZeroDivisionError:
    print("Zero Division!")
    
print("The END")
"""

##Exception in function
"""
def badFun(n):
    try:
        return 1/n
    except ArithmeticError:
        print("Arithmetic problem!")
    return None
badFun(0)
print("The End")
"""

#Exception out of function
def badFun(n):
    return 1/n
try:
    badFun(0)
except ArithmeticError:
   print("What happened? An exception was raised!")
print("The End")